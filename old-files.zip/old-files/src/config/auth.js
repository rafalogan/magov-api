export default {
  secret: process.env.APP_SECRET,
  expiresIn: '2d',
};
