import app from './app.js';

app.listen(6001, "0.0.0.0");
