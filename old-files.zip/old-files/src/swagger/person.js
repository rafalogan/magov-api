

/* MODEL Person */
function addPerson(param) {
    return true
}

function getPerson(param) {
    const person = {
        name: 'person',
        birth_date: 1990-11-05,
        address: 'person address',
    }
    return person;
}


module.exports = {
    addPerson,
    getPerson
}
