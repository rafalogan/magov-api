import jwt from 'jsonwebtoken';
import * as Yup from 'yup';
import authConfig from '../../config/auth.js';
import Address from '../models/Address.js';
import Contact from '../models/Contact.js';
import Person from '../models/Person.js';
import PhysicalPerson from '../models/PhysicalPerson.js';
import Role from '../models/Role.js';
import User from '../models/User.js';
import utils from './utils.js';
import CryptoJS from 'crypto-js';


let include = [
    utils.include(
        PhysicalPerson,
        { active: true },
        true,
        null,
        utils.include(Person, { active: true }, true, null, [
            utils.include(Address, { active: true }, true, null, null, null),
            utils.include(Contact, { active: true }, true, null, null, null)
        ]),
        'pf'
    ),
    utils.include(Role, { active: true }, true, null, null, null)
];
class SessionController {
    async store(req, res) {
        
        if (!req.body || !req.body.email || !req.body.password)
            return res.status(400).json({ error: 'Validation session fails' });

        const { email, password } = req.body;

        const passwordToDecrypt = CryptoJS.AES.decrypt(password, 'password')
        const decrypt = passwordToDecrypt.toString(CryptoJS.enc.Utf8)

        let user = await User.findOne({ where: { email } });

        if (!user) return res.status(401).json({ error: 'User not found' });

        if (!user.physical_person) {
            user = await User.findOne({ where: { email } });
        } else {
            user = await User.findOne({ where: { email }, include });
        }

        if (!(await user.checkPassword(decrypt)))
            return res.status(401).json({ error: 'Password does not match' });

        if (!user.active)
            return res.status(401).json({ error: 'User is not active' });

        let data_last_acess = new Date();
        let current_last_acess = new Date(
            data_last_acess.valueOf() -
                data_last_acess.getTimezoneOffset() * 60000
        );

        await user.update({ updated_at: data_last_acess });

        return res.json({
            user: {
                active: user.active,
                createdAt: user.createdAt,
                email: user.email,
                company: user.company,
                id: user.id,
                physical_person: user.physical_person,
                pf: user.pf,
                updatedAt: user.updatedAt,
                unit: user.unit
            },
            token: jwt.sign({ id: user.id }, authConfig.secret, {
                expiresIn: authConfig.expiresIn
            })
        });
    }

    async decodeToken(token) {
        return { user: id, token: jwt.decode(token) };
    }
}

export default new SessionController();
